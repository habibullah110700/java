package com.example.sapikudadankerbau.model;

public class Kuda extends Hewan{

    public Kuda(String ras, String asal, String deskripsi, int drawableRes) {
        super("Kuda",ras,asal,deskripsi,drawableRes);

    }

}