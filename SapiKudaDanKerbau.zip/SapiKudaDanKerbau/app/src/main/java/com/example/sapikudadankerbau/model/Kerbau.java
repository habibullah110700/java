package com.example.sapikudadankerbau.model;

public class Kerbau extends Hewan{

    public Kerbau(String ras, String asal, String deskripsi, int drawableRes) {
        super("Kerbau",ras,asal,deskripsi,drawableRes);

    }

}