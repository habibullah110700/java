package com.example.sapikudadankerbau.model;

public class Sapi extends Hewan{

    public Sapi(String ras, String asal, String deskripsi, int drawableRes) {
        super("Sapi",ras,asal,deskripsi,drawableRes);

    }

}